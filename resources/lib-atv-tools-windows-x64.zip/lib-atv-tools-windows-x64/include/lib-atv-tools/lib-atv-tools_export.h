
#ifndef LIB_ATV_TOOLS_EXPORT_H
#define LIB_ATV_TOOLS_EXPORT_H

#ifdef LIB_ATV_TOOLS_STATIC_DEFINE
#  define LIB_ATV_TOOLS_EXPORT
#  define LIB_ATV_TOOLS_NO_EXPORT
#else
#  ifndef LIB_ATV_TOOLS_EXPORT
#    ifdef lib_atv_tools_EXPORTS
        /* We are building this library */
#      define LIB_ATV_TOOLS_EXPORT __declspec(dllexport)
#    else
        /* We are using this library */
#      define LIB_ATV_TOOLS_EXPORT __declspec(dllimport)
#    endif
#  endif

#  ifndef LIB_ATV_TOOLS_NO_EXPORT
#    define LIB_ATV_TOOLS_NO_EXPORT 
#  endif
#endif

#ifndef LIB_ATV_TOOLS_DEPRECATED
#  define LIB_ATV_TOOLS_DEPRECATED __declspec(deprecated)
#endif

#ifndef LIB_ATV_TOOLS_DEPRECATED_EXPORT
#  define LIB_ATV_TOOLS_DEPRECATED_EXPORT LIB_ATV_TOOLS_EXPORT LIB_ATV_TOOLS_DEPRECATED
#endif

#ifndef LIB_ATV_TOOLS_DEPRECATED_NO_EXPORT
#  define LIB_ATV_TOOLS_DEPRECATED_NO_EXPORT LIB_ATV_TOOLS_NO_EXPORT LIB_ATV_TOOLS_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIB_ATV_TOOLS_NO_DEPRECATED
#    define LIB_ATV_TOOLS_NO_DEPRECATED
#  endif
#endif

#endif /* LIB_ATV_TOOLS_EXPORT_H */
