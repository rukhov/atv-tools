#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "lib-atv-tools::lib-atv-tools" for configuration "Release"
set_property(TARGET lib-atv-tools::lib-atv-tools APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(lib-atv-tools::lib-atv-tools PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/lib-atv-tools.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "kissfft::kissfft-float"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/lib-atv-tools.dll"
  )

list(APPEND _cmake_import_check_targets lib-atv-tools::lib-atv-tools )
list(APPEND _cmake_import_check_files_for_lib-atv-tools::lib-atv-tools "${_IMPORT_PREFIX}/lib/lib-atv-tools.lib" "${_IMPORT_PREFIX}/bin/lib-atv-tools.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
