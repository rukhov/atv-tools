/*
 * This file is part of the analot-tv-tools project.
 * Copyright (c) 2025 Roman Ukhov <ukhov.roman@gmail.com>
 */

#pragma once

#include "lib-atv-tools_export.h"

#include <functional>
#include <memory>
#include <span>

#if !defined(FIXED_SAMPLE_RATE)
#define FIXED_SAMPLE_RATE 16000000
#endif

namespace atv {

enum class standard_e { SECAM = 0, NTSC = 1, PAL = 2 };

class LIB_ATV_TOOLS_EXPORT decoder
{
public:
#pragma pack(push, 1)
    struct RGB_color {
        unsigned char r;
        unsigned char g;
        unsigned char b;

        RGB_color() : r(0), g(0), b(0) {}
        RGB_color(unsigned char _r, unsigned char _g, unsigned char _b)
            : r(_r), g(_g), b(_b)
        {
        }
    };
#pragma pack(pop)

    using frame_ready_cb = std::function<void(std::span<RGB_color> const&,
                                              size_t viewport_rect_x,
                                              size_t viewport_rect_y,
                                              size_t viewport_rect_width,
                                              size_t viewport_rect_height,
                                              size_t total_width,
                                              size_t total_height)>;

    virtual ~decoder() = default;

    virtual void process(uint64_t length,
                         float const* input,
                         short* video_yout = nullptr,
                         short* video_uout = nullptr,
                         short* video_vout = nullptr,
                         float* luma_out = nullptr) = 0;

    virtual void process_outstanding_tasks() = 0;

    // Fixed sample rate for now = 16000000
    static std::unique_ptr<decoder> make(standard_e standard,
                                         frame_ready_cb frame_cb,
                                         uint64_t samp_rate = FIXED_SAMPLE_RATE);
};

} // namespace atv